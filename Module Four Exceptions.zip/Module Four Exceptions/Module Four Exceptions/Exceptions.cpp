// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

using namespace std;

//Creating custom exception from std::exception library. This will be used in the do_custom_application_logic() method
struct myCustomException : public std::exception {
    virtual const char* what() const throw() {
        return "Returning Kelly's custom exception.";
    }
};

bool do_even_more_custom_application_logic()
{
    //Throwing a standard exception using throw
    throw std::bad_exception();

    std::cout << "Running Even More Custom Application Logic." << std::endl;
       
    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    //Implementing try/catch with exception.what() logic
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    //what() returns a null terminated sequence that can identify the exception
    catch (std::exception& e) {
        std::cout << "Exception error! " << e.what() << "." << std::endl;
    }
    //Throwing my custom exception and catching it explicitly in main()
    throw myCustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    //Throwing exception for divide by zero errors
    if (den == 0) {
        throw std::overflow_error("Error! Division by zero not allowed.");
    }
    return (num / den);
}

void do_division() noexcept
{
    //Creating an exception handler to capture the exception thrown by divide

    float numerator = 10.0f;
    float denominator = 0;

    //Using try/catch to catch the divison exception
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //Catching overflow (divide by zero) exception
    catch (std::overflow_error& e) {
        std::cout << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    //Creating try/catch blocks that catch all of the above exceptions
    try {
        do_custom_application_logic();
    }
    catch (std::exception& e) {
        std::cout << e.what() << std::endl;
    }
    try {
        do_division();
    }
    catch (...) {
        throw "Error! Please try again.";
    }
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu